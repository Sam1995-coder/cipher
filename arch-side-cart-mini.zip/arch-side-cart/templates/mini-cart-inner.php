<?php
// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Inner contents of the cart drawer.
 *
 * This is the *contents* that go inside #arch-cart-drawer-inner. It is
 * included only by arch_render_cart_drawer_inner() in includes/cart-functions.php,
 * which wraps it in a fresh #arch-cart-drawer-inner div. That helper is used by:
 *  - templates/mini-cart.php, for the full drawer markup printed once on page load.
 *  - includes/ajax.php and includes/hooks.php (fragments), for AJAX cart refreshes,
 *    so cart-drawer.js can swap it in with
 *    $drawer.find('.arch-cart-inner').replaceWith(html) and keep the id intact.
 *
 * IMPORTANT: this file must NOT include the #arch-cart-overlay or the outer
 * #arch-cart-drawer wrapper. Including the outer wrapper here is what caused
 * a duplicate nested #arch-cart-drawer element after every cart AJAX update.
 */

$cart              = WC()->cart;
$items             = $cart ? $cart->get_cart() : [];
$item_count        = arch_cart_item_count();
$total             = arch_cart_total();
$shipping_progress = arch_free_shipping_progress();
$shipping_left     = arch_free_shipping_remaining();
$cart_title        = arch_side_cart_get_option( 'cart_title' );
$checkout_text     = arch_side_cart_get_option( 'checkout_button_text' );
$show_badge        = arch_side_cart_get_option( 'show_badge' );
$badge_text        = arch_side_cart_get_option( 'badge_text' );
$show_ship_bar     = arch_side_cart_get_option( 'show_shipping_bar' );
$progress_text     = arch_side_cart_get_option( 'shipping_progress_text' );
$unlocked_text     = arch_side_cart_get_option( 'shipping_unlocked_text' );
$tax_note          = arch_side_cart_get_option( 'tax_note' );
$empty_text        = arch_side_cart_get_option( 'empty_cart_text' );
$checkout_url      = wc_get_checkout_url();
?>
<!-- HEADER -->
<div class="arch-cart-header">
    <div class="arch-cart-header-left">
        <span class="arch-item-count"><?php echo esc_html( (int) $item_count ); ?> <?php echo esc_html( _n( 'ITEM', 'ITEMS', $item_count, 'arch-side-cart' ) ); ?></span>
        <h2 class="arch-cart-title"><?php echo esc_html( $cart_title ); ?></h2>
    </div>
    <button type="button" class="arch-cart-close" aria-label="<?php esc_attr_e( 'Close cart', 'arch-side-cart' ); ?>" id="arch-cart-close">&#10005;</button>
</div>

<!-- FREE SHIPPING PROGRESS -->
<?php if ( $show_ship_bar ) : ?>
<div class="arch-shipping-bar">
    <?php if ( $shipping_left <= 0 ) : ?>
        <div class="arch-shipping-label arch-shipping-unlocked">
            <span class="arch-check" aria-hidden="true">&#10003;</span>
            <span><?php echo esc_html( $unlocked_text ); ?></span>
        </div>
    <?php else : ?>
        <div class="arch-shipping-label">
            <span><?php echo wp_kses_post( str_replace( '{amount}', '<strong>' . wc_price( $shipping_left ) . '</strong>', esc_html( $progress_text ) ) ); ?></span>
        </div>
    <?php endif; ?>
    <div class="arch-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( $shipping_progress ); ?>">
        <div class="arch-progress-fill" style="width: <?php echo esc_attr( $shipping_progress ); ?>%"></div>
    </div>
</div>
<?php endif; ?>

<!-- CART ITEMS -->
<div class="arch-cart-items">
    <?php if ( empty( $items ) ) : ?>
        <p class="arch-empty"><?php echo esc_html( $empty_text ); ?></p>
    <?php else : ?>
        <?php foreach ( $items as $key => $item ) :
            $product       = $item['data'];
            $qty           = (int) $item['quantity'];
            $line_price    = (float) $item['line_total'];
            $reg_price     = (float) $product->get_regular_price() * $qty;
            $tier          = arch_get_tier_for_qty( $qty );
            $tier_pct      = $tier ? $tier['pct'] : 0;
            // Tier discount is applied cart-wide as a fee (so taxes/totals stay correct),
            // but we still show the per-item "was / now / save" breakdown here so the
            // customer can see the saving on the exact line it applies to.
            $tier_discount = $line_price * ( $tier_pct / 100 );
            $display_price = $line_price - $tier_discount;
            $savings       = ( $reg_price - $line_price ) + $tier_discount;
            $bundle_msg    = arch_item_bundle_message( $item );
            $upsell_msg    = arch_item_upsell_message( $item );
            $img           = $product->get_image( [80, 80] );
        ?>
        <div class="arch-cart-item" data-key="<?php echo esc_attr( $key ); ?>">
            <div class="arch-item-image"><?php echo wp_kses_post( $img ); ?></div>
            <div class="arch-item-details">
                <div class="arch-item-top">
                    <div class="arch-item-info">
                        <p class="arch-item-name"><?php echo esc_html( $product->get_name() ); ?></p>
                        <?php if ( ! empty( $item['variation'] ) ) :
                            foreach ( $item['variation'] as $attr => $val ) :
                                if ( ! $val ) continue;
                        ?>
                            <p class="arch-item-meta"><?php echo esc_html( wc_attribute_label( str_replace( 'attribute_', '', $attr ) ) ); ?>: <?php echo esc_html( $val ); ?></p>
                        <?php endforeach; endif; ?>

                        <?php if ( $bundle_msg ) : ?>
                            <p class="arch-bundle-msg">
                                <?php echo esc_html( $bundle_msg ); ?>
                                <?php if ( $show_badge && $badge_text !== '' ) : ?> &bull; <span class="arch-coa"><?php echo esc_html( $badge_text ); ?></span><?php endif; ?>
                            </p>
                        <?php elseif ( $show_badge && $badge_text !== '' ) : ?>
                            <p class="arch-bundle-msg"><span class="arch-coa"><?php echo esc_html( $badge_text ); ?></span></p>
                        <?php endif; ?>
                    </div>
                    <div class="arch-item-price-wrap">
                        <?php if ( $savings > 0.01 ) : ?>
                            <span class="arch-item-reg-price"><?php echo wp_kses_post( wc_price( $reg_price ) ); ?></span>
                        <?php endif; ?>
                        <span class="arch-item-price"><?php echo wp_kses_post( wc_price( $display_price ) ); ?></span>
                        <?php if ( $savings > 0.01 ) : ?>
                            <span class="arch-save-badge"><?php esc_html_e( 'SAVE', 'arch-side-cart' ); ?> <?php echo wp_kses_post( wc_price( $savings ) ); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- QTY CONTROLS -->
                <div class="arch-item-actions">
                    <div class="arch-qty-wrap">
                        <button type="button" class="arch-qty-btn arch-qty-minus" data-key="<?php echo esc_attr( $key ); ?>" aria-label="<?php esc_attr_e( 'Decrease quantity', 'arch-side-cart' ); ?>">&#8722;</button>
                        <span class="arch-qty-num" aria-live="polite"><?php echo esc_html( (int) $qty ); ?></span>
                        <button type="button" class="arch-qty-btn arch-qty-plus"  data-key="<?php echo esc_attr( $key ); ?>" aria-label="<?php esc_attr_e( 'Increase quantity', 'arch-side-cart' ); ?>">&#43;</button>
                    </div>
                    <button type="button" class="arch-remove-btn" data-key="<?php echo esc_attr( $key ); ?>"><?php esc_html_e( 'REMOVE', 'arch-side-cart' ); ?></button>
                </div>
            </div>
        </div>

        <!-- UPSELL BANNER (per item) -->
        <?php if ( $upsell_msg ) :
            $upsell_need = arch_item_upsell_qty_needed( $item );
        ?>
        <div class="arch-upsell-banner">
            <span class="arch-tag-icon">&#127991;</span>
            <span class="arch-upsell-text">
                <b><?php echo esc_html( $upsell_msg ); ?></b>
                <p>
                    &bull; <?php echo esc_html( $product->get_name() ); ?> &bull; <?php esc_html_e( 'bundle pricing auto-applied', 'arch-side-cart' ); ?>
                </p>
            </span>
            <button type="button" class="arch-add-one-btn" data-key="<?php echo esc_attr( $key ); ?>" data-add-qty="<?php echo esc_attr( (int) $upsell_need ); ?>">
                <?php echo esc_html( sprintf( /* translators: %d: quantity */ __( 'ADD %d', 'arch-side-cart' ), (int) $upsell_need ) ); ?>
            </button>
        </div>
        <?php endif; ?>

        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- FOOTER -->
<div class="arch-cart-footer">
    <div class="arch-subtotal-row">
        <span class="arch-subtotal-label"><?php esc_html_e( 'Subtotal', 'arch-side-cart' ); ?></span>
        <span class="arch-subtotal-amount"><?php echo wp_kses_post( wc_price( $total ) ); ?></span>
    </div>
    <?php if ( $tax_note !== '' ) : ?>
    <p class="arch-tax-note"><?php echo esc_html( $tax_note ); ?></p>
    <?php endif; ?>
    <a href="<?php echo esc_url( $checkout_url ); ?>" class="arch-checkout-btn">
        <?php echo esc_html( $checkout_text ); ?> &rarr;
    </a>
    <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="arch-view-cart"><?php esc_html_e( 'VIEW CART', 'arch-side-cart' ); ?></a>
</div>
