<?php
// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Full cart drawer markup: overlay + outer #arch-cart-drawer wrapper.
 * Used once, on page load, via wp_footer (see includes/hooks.php).
 *
 * The actual cart contents live in templates/mini-cart-inner.php, rendered
 * here through arch_render_cart_drawer_inner() so the markup matches exactly
 * what AJAX refreshes later swap in. Do not print the inner contents here
 * directly — printing this outer wrapper a second time (e.g. from an AJAX
 * fragment) is what previously caused a duplicate nested #arch-cart-drawer.
 */
$cart_title = arch_side_cart_get_option( 'cart_title' );
?>

<!-- OVERLAY (outside drawer, sibling element) -->
<div id="arch-cart-overlay" class="arch-cart-overlay" aria-hidden="true"></div>

<!-- DRAWER -->
<div id="arch-cart-drawer" class="arch-cart-drawer" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr( $cart_title ); ?>" aria-hidden="true">
    <?php echo wp_kses_post( arch_render_cart_drawer_inner() ); ?>
</div><!-- /#arch-cart-drawer -->
