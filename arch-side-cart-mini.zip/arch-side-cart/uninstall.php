<?php
/**
 * Runs when the plugin is deleted from the Plugins screen.
 *
 * @package Arch_Side_Cart
 */

// Security: block direct access; only WordPress may trigger an uninstall.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

delete_option( 'arch_side_cart_options' );
delete_option( 'arch_side_cart_db_version' );
