/**
 * Arch Side Cart – cart-drawer.js
 * Handles open/close, qty updates, remove, add-one upsell.
 */
(function ($) {
    'use strict';

    var $drawer, $overlay, $inner, isLoading = false;

    /* ── Init ── */
    function init() {
        $drawer  = $('#arch-cart-drawer');
        $overlay = $('#arch-cart-overlay');
        $inner   = $('#arch-cart-drawer-inner');

        if (!$drawer.length) return;

        bindStaticEvents();
        refreshCartCount();
    }

    /* ── Open / Close ── */
    var lastFocus = null;

    function openDrawer() {
        if (!$drawer.hasClass('arch-open')) {
            lastFocus = document.activeElement;
        }
        $drawer.addClass('arch-open');
        $overlay.addClass('arch-open');
        $('body').addClass('arch-drawer-open');
        $drawer.attr('aria-hidden', 'false');
        $overlay.attr('aria-hidden', 'false');
        // Move focus into the drawer for keyboard / screen-reader users.
        setTimeout(function () { $('#arch-cart-close').trigger('focus'); }, 50);
    }

    function closeDrawer() {
        $drawer.removeClass('arch-open');
        $overlay.removeClass('arch-open');
        $('body').removeClass('arch-drawer-open');
        $drawer.attr('aria-hidden', 'true');
        $overlay.attr('aria-hidden', 'true');
        if (lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) {} }
    }

    /* ── AJAX helper ── */
    function doAjax(action, data, callback) {
        if (isLoading) return;
        isLoading = true;
        $inner.addClass('arch-loading');

        var payload = $.extend({ action: action, nonce: archCart.nonce }, data);

        $.post(archCart.ajaxUrl, payload, function (res) {
            if (res.success) {
                if (res.data.html) {
                    $drawer.find('.arch-cart-inner').replaceWith(res.data.html);
                    $inner = $('#arch-cart-drawer-inner');
                    bindDelegatedEvents();
                }
                if (typeof res.data.count !== 'undefined') {
                    updateCountBadges(res.data.count);
                }
                if (callback) callback(res.data);
            }
        }).always(function () {
            isLoading = false;
            $inner.removeClass('arch-loading');
        });
    }

    /* ── Static events ── */
    function bindStaticEvents() {

        // Close button
        $(document).on('click', '#arch-cart-close', closeDrawer);

        // Overlay click
        $overlay.on('click', closeDrawer);

        // ESC key
        $(document).on('keydown', function (e) {
            if (!$drawer.hasClass('arch-open')) return;
            if (e.key === 'Escape') { closeDrawer(); return; }
            if (e.key === 'Tab') {
                var $f = $drawer.find('a[href], button:not([disabled])').filter(':visible');
                if (!$f.length) return;
                var first = $f[0], last = $f[$f.length - 1];
                if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
            }
        });

        // ── EXACT: HFE Header Footer Elementor cart widget ──
        // Targets: #hfe-menu-cart__toggle_button and its parent chain
        $(document).on('click',
            '#hfe-menu-cart__toggle_button, .hfe-cart-container, .hfe-site-header-cart a, .hfe-menu-cart__toggle a, [id="hfe-menu-cart__toggle_button"]',
            function (e) {
                e.preventDefault();
                e.stopImmediatePropagation();
                openDrawer();
                return false;
            }
        );

        // ── Generic fallback for other themes ──
        $(document).on('click', 'a[href], button', function (e) {
            var $el  = $(this);
            var href = ($el.attr('href') || '').replace(/\/$/, '');

            // Skip if inside HFE cart widget (already handled above)
            if ($el.closest('.hfe-site-header-cart, .hfe-menu-cart__toggle').length) return;

            // Skip anything inside our own drawer
            if ($el.closest('#arch-cart-drawer').length) return;

            // Match links that point at the cart page itself. Compare paths
            // exactly (a plain substring test also caught things like
            // "/cartoons/" and WooCommerce's own "/cart/?remove_item=..."
            // links), and leave links that carry a query string alone.
            var isCartUrl = false;
            if (href && href.indexOf('?') === -1 && href.charAt(0) !== '#') {
                try {
                    var target   = new URL(href, window.location.href);
                    var cartPath = new URL(archCart.cartUrl, window.location.href);
                    isCartUrl = target.origin === cartPath.origin &&
                        target.pathname.replace(/\/$/, '') === cartPath.pathname.replace(/\/$/, '');
                } catch (err) { isCartUrl = false; }
            }

            // Match data attribute trigger
            var isTrigger = $el.is('[data-arch-open-cart]');

            if (isCartUrl || isTrigger) {
                e.preventDefault();
                e.stopImmediatePropagation();
                openDrawer();
                return false;
            }
        });

        // Custom "arch_added_to_cart" event – fired by our own AJAX
        // add-to-cart scripts (single product page form, [arch_buy_now]
        // shortcode button). Deliberately NOT named "added_to_cart" —
        // that name collides with WooCommerce core's own wc-cart-fragments
        // listener, which expects a WC-shaped fragments object as the 2nd
        // arg and throws (HierarchyRequestError) when given our { html,
        // count } shape instead. Using our own event name avoids that
        // entirely while keeping this listener's logic unchanged.
        $(document.body).on('arch_added_to_cart', function (e, data) {
            if (data && data.html) {
                $drawer.find('.arch-cart-inner').replaceWith(data.html);
                $inner = $('#arch-cart-drawer-inner');
                bindDelegatedEvents();
                if (typeof data.count !== 'undefined') {
                    updateCountBadges(data.count);
                }
                openDrawer();
                return;
            }
            // Fallback: no usable data was passed (e.g. a native
            // WooCommerce add-to-cart elsewhere triggered this event with
            // its own fragments format) — fetch fresh drawer HTML.
            doAjax('arch_get_cart', {}, function () { openDrawer(); });
        });

        bindDelegatedEvents();
    }

    /* ── Delegated events (re-bound after AJAX re-render) ── */
    function bindDelegatedEvents() {
        $(document)
            .off('.archCart')
            .on('click.archCart', '.arch-qty-plus', function () {
                var key = $(this).data('key');
                var qty = parseInt($(this).closest('.arch-item-actions').find('.arch-qty-num').text(), 10) + 1;
                doAjax('arch_update_qty', { cart_item_key: key, quantity: qty });
            })
            .on('click.archCart', '.arch-qty-minus', function () {
                var key = $(this).data('key');
                var qty = Math.max(0, parseInt($(this).closest('.arch-item-actions').find('.arch-qty-num').text(), 10) - 1);
                doAjax('arch_update_qty', { cart_item_key: key, quantity: qty });
            })
            .on('click.archCart', '.arch-remove-btn', function () {
                var key = $(this).data('key');
                doAjax('arch_remove_item', { cart_item_key: key });
            })
            .on('click.archCart', '.arch-add-one-btn', function () {
                var key = $(this).data('key');
                var addQty = parseInt($(this).data('addQty'), 10) || 1;
                doAjax('arch_add_one', { cart_item_key: key, add_qty: addQty });
            });
    }

    /* ── Update count badges ── */
    function updateCountBadges(count) {
        var selectors = [
            '.cart-count',
            '.cart-contents-count',
            '.woocommerce-cart-count',
            '[data-arch-cart-count]',
            '.arch-cart-count-badge',
        ];
        $(selectors.join(',')).text(count);
    }

    function refreshCartCount() {
        doAjax('arch_get_cart', {}, function (data) {
            updateCountBadges(data.count);
        });
    }

    /* ── Ready ── */
    $(document).ready(init);

})(jQuery);
