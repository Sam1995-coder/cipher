/* Arch Side Cart – admin UI behaviour */
(function () {
    'use strict';

    var wrap = document.querySelector('.asc-wrap');
    if (!wrap) return;
    wrap.classList.add('asc-js');

    var form = document.getElementById('asc-form');
    var currency = (window.archAdmin && window.archAdmin.currency) || '$';

    /* ---------- Tabs (remembers last tab via hash) ---------- */
    var tabs = wrap.querySelectorAll('.asc-tab');
    var panels = wrap.querySelectorAll('.asc-panel');

    function showTab(name) {
        var found = false;
        tabs.forEach(function (t) { if (t.dataset.tab === name) found = true; });
        if (!found) name = 'general';
        tabs.forEach(function (t) {
            var on = t.dataset.tab === name;
            t.classList.toggle('is-active', on);
            t.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        panels.forEach(function (p) { p.classList.toggle('is-active', p.dataset.panel === name); });
    }
    tabs.forEach(function (t) {
        t.addEventListener('click', function () {
            showTab(t.dataset.tab);
            try { history.replaceState(null, '', '#' + t.dataset.tab); } catch (e) {}
        });
    });
    showTab((location.hash || '').replace('#', ''));

    /* ---------- Quantity tiers repeater ---------- */
    var rows = document.getElementById('asc-tier-rows');
    var tpl = document.getElementById('asc-tier-template');
    var addBtn = document.getElementById('asc-tier-add');
    var nextIndex = parseInt(rows.getAttribute('data-next'), 10) || 0; // never reused, so removing a row can't cause index collisions

    addBtn.addEventListener('click', function () {
        var html = tpl.innerHTML.replace(/__I__/g, String(nextIndex++));
        var holder = document.createElement('div');
        holder.innerHTML = html.trim();
        var row = holder.firstElementChild;
        rows.appendChild(row);
        var first = row.querySelector('input');
        if (first) first.focus();
        markDirty();
    });
    rows.addEventListener('click', function (e) {
        var btn = e.target.closest('.asc-tier-remove');
        if (!btn) return;
        var row = btn.closest('.asc-tier-row');
        if (row) row.parentNode.removeChild(row);
        markDirty();
    });

    /* ---------- Colour picker (native picker + hex field + swatches) ---------- */
    var picker = document.getElementById('asc-accent_color');
    var hex = document.getElementById('asc-accent_color_hex');

    function normHex(v) {
        v = (v || '').trim();
        if (v.charAt(0) !== '#') v = '#' + v;
        if (/^#[0-9a-f]{3}$/i.test(v)) v = '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
        return /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : null;
    }
    function setColor(v) {
        var n = normHex(v);
        if (!n) return;
        picker.value = n;
        hex.value = n;
        updatePreview();
    }
    picker.addEventListener('input', function () { setColor(picker.value); markDirty(); });
    hex.addEventListener('input', function () { var n = normHex(hex.value); if (n) { picker.value = n; updatePreview(); } markDirty(); });
    hex.addEventListener('blur', function () { var n = normHex(hex.value); hex.value = n || picker.value; updatePreview(); });
    wrap.querySelectorAll('.asc-swatch').forEach(function (s) {
        s.addEventListener('click', function () { setColor(s.dataset.color); markDirty(); });
    });

    /* ---------- Live preview ---------- */
    var pv = document.getElementById('asc-pv');

    function val(key) {
        var el = form.querySelector('[data-preview="' + key + '"]');
        return el ? el.value : '';
    }
    function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }
    function contrast(h) {
        var r = parseInt(h.substr(1, 2), 16), g = parseInt(h.substr(3, 2), 16), b = parseInt(h.substr(5, 2), 16);
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.6 ? '#1d1d1f' : '#ffffff';
    }
    function updatePreview() {
        var c = normHex(val('accent_color')) || '#046bd2';
        var r = parseInt(c.substr(1, 2), 16), g = parseInt(c.substr(3, 2), 16), b = parseInt(c.substr(5, 2), 16);
        pv.style.setProperty('--pv', c);
        pv.style.setProperty('--pv-rgb', r + ', ' + g + ', ' + b);
        pv.style.setProperty('--pv-ink', contrast(c));
        wrap.style.setProperty('--asc-accent', c);
        wrap.style.setProperty('--asc-accent-rgb', r + ', ' + g + ', ' + b);

        pv.querySelectorAll('[data-bind]').forEach(function (el) {
            el.textContent = val(el.dataset.bind);
        });

        var amount = '<strong>' + esc(currency) + '43.00</strong>';
        pv.querySelector('.asc-pv-locked').innerHTML = esc(val('shipping_progress_text')).replace(/\{amount\}/g, amount);

        var shipOn = form.querySelector('#asc-show_shipping_bar').checked;
        pv.querySelector('[data-bind-show="ship"]').hidden = !shipOn;
        pv.querySelector('[data-bind-show="badge"]').hidden = !form.querySelector('#asc-show_badge').checked;
    }

    form.addEventListener('input', function (e) {
        if (e.target.matches('[data-preview], input[type="checkbox"]')) updatePreview();
    });
    form.addEventListener('change', function (e) {
        if (e.target.matches('input[type="checkbox"]')) updatePreview();
    });

    wrap.querySelectorAll('.asc-seg button').forEach(function (btn) {
        btn.addEventListener('click', function () {
            wrap.querySelectorAll('.asc-seg button').forEach(function (b) { b.classList.toggle('is-active', b === btn); });
            pv.setAttribute('data-state', btn.dataset.state);
        });
    });

    /* ---------- Unsaved changes indicator ---------- */
    var dirty = document.getElementById('asc-dirty');
    var isDirty = false;
    function markDirty() { isDirty = true; dirty.hidden = false; }
    form.addEventListener('input', markDirty);
    form.addEventListener('change', markDirty);
    form.addEventListener('submit', function () { isDirty = false; });
    window.addEventListener('beforeunload', function (e) {
        if (isDirty) { e.preventDefault(); e.returnValue = ''; }
    });

    /* ---------- Fade the "saved" toast ---------- */
    var toast = wrap.querySelector('.asc-toast');
    if (toast) setTimeout(function () { toast.style.transition = 'opacity .5s'; toast.style.opacity = '0'; setTimeout(function () { toast.remove(); }, 600); }, 3500);
    // Drop the query flag so a refresh doesn't re-show it.
    try { var u = new URL(location.href); if (u.searchParams.has('settings-updated')) { u.searchParams.delete('settings-updated'); history.replaceState(null, '', u.toString()); } } catch (e) {}

    updatePreview();
})();
