<?php
/**
 * Plugin Name:       Arch Side Cart
 * Description:       A modern WooCommerce side cart drawer with a free-shipping progress bar, quantity-based bundle discounts, a customisable trust badge and a one-click checkout button.
 * Version:           1.1.0
 * Author:            Arch
 * License:           GPL-2.0+
 * Text Domain:       arch-side-cart
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Requires Plugins:  woocommerce
 * WC requires at least: 6.0
 * WC tested up to:   9.4
 */

// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ARCH_SIDE_CART_VERSION', '1.1.0' );
define( 'ARCH_SIDE_CART_FILE',    __FILE__ );
define( 'ARCH_SIDE_CART_PATH',    plugin_dir_path( __FILE__ ) );
define( 'ARCH_SIDE_CART_URL',     plugin_dir_url( __FILE__ ) );

/**
 * Declare compatibility with WooCommerce features.
 *
 * This removes the "WooCommerce has detected that some of your active plugins
 * are incompatible with currently enabled WooCommerce features" warning.
 * It must run on `before_woocommerce_init`, and must be registered while the
 * plugin file loads (i.e. NOT inside plugins_loaded).
 *  - custom_order_tables : HPOS. The plugin never reads/writes orders directly.
 *  - cart_checkout_blocks: The plugin does not alter cart/checkout page markup;
 *                          its quantity discount is a standard cart fee, which
 *                          the Cart & Checkout blocks support.
 */
add_action( 'before_woocommerce_init', function () {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', ARCH_SIDE_CART_FILE, true );
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', ARCH_SIDE_CART_FILE, true );
    }
} );

// Boot once all plugins are loaded so we can check WooCommerce is active.
add_action( 'plugins_loaded', 'arch_side_cart_init' );
function arch_side_cart_init() {
    load_plugin_textdomain( 'arch-side-cart', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>Arch Side Cart</strong> ' . esc_html__( 'requires WooCommerce to be installed and active.', 'arch-side-cart' ) . '</p></div>';
        } );
        return;
    }

    require_once ARCH_SIDE_CART_PATH . 'includes/settings.php';
    require_once ARCH_SIDE_CART_PATH . 'includes/admin-page.php';
    require_once ARCH_SIDE_CART_PATH . 'includes/cart-functions.php';
    require_once ARCH_SIDE_CART_PATH . 'includes/ajax.php';
    require_once ARCH_SIDE_CART_PATH . 'includes/hooks.php';
    require_once ARCH_SIDE_CART_PATH . 'includes/shortcode.php';

    // Prevent WooCommerce from redirecting to the cart page after add-to-cart.
    add_filter( 'woocommerce_add_to_cart_redirect',    '__return_false' );
    add_filter( 'woocommerce_cart_redirect_after_add', '__return_false' );
}

// "Settings" shortcut on the Plugins screen.
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
    $url = admin_url( 'admin.php?page=arch-side-cart' );
    array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'arch-side-cart' ) . '</a>' );
    return $links;
} );
