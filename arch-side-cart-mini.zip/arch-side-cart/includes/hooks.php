<?php
// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enqueue front-end assets.
 * Load at priority 999 so we run AFTER HFE/Elementor scripts.
 */
add_action( 'wp_enqueue_scripts', 'arch_side_cart_enqueue', 999 );
function arch_side_cart_enqueue() {
	wp_enqueue_script(
		'arch-side-cart',
		ARCH_SIDE_CART_URL . 'assets/js/cart-drawer.js',
		array( 'jquery' ),
		ARCH_SIDE_CART_VERSION,
		true
	);

	wp_enqueue_style(
		'arch-side-cart',
		ARCH_SIDE_CART_URL . 'assets/css/cart-drawer.css',
		array(),
		ARCH_SIDE_CART_VERSION
	);

    wp_localize_script( 'arch-side-cart', 'archCart', [
        'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
        'nonce'       => wp_create_nonce( 'arch_side_cart_nonce' ),
        'checkoutUrl' => esc_url_raw( wc_get_checkout_url() ),
        'cartUrl'     => esc_url_raw( wc_get_cart_url() ),
        'accentColor' => sanitize_hex_color( (string) arch_side_cart_get_option( 'accent_color' ) ),
    ] );

    // Accent colour -> CSS variables (plus an RGB triplet for tints and a readable text colour).
    $accent = sanitize_hex_color( arch_side_cart_get_option( 'accent_color' ) );
    if ( ! $accent ) $accent = '#046bd2';
    list( $r, $g, $b ) = arch_side_cart_hex_to_rgb( $accent );
    $contrast = arch_side_cart_contrast_color( $accent );
    // SECURITY: $accent is validated by sanitize_hex_color(); $r/$g/$b are ints from hexdec().
    $r = (int) $r; $g = (int) $g; $b = (int) $b;
    wp_add_inline_style( 'arch-side-cart', ":root { --arch-accent: {$accent}; --arch-accent-rgb: {$r}, {$g}, {$b}; --arch-accent-ink: {$contrast}; }" );

    // Inline JS injected at priority 999 AFTER all other scripts.
    // Removes href + rewrites onclick on the HFE cart button so nothing
    // can redirect to the cart page — no race condition possible.
    wp_add_inline_script( 'arch-side-cart', "
        (function() {
            function patchHfeCart() {
                // Target the exact HFE cart anchor by ID and class
                var selectors = [
                    '#hfe-menu-cart__toggle_button',
                    '.hfe-cart-container',
                    '.hfe-site-header-cart a',
                    '.hfe-menu-cart__toggle a'
                ];
                selectors.forEach(function(sel) {
                    document.querySelectorAll(sel).forEach(function(el) {
                        // Strip the href so the browser won't navigate
                        el.removeAttribute('href');
                        el.style.cursor = 'pointer';

                        // Clone to remove all existing event listeners
                        var clone = el.cloneNode(true);
                        el.parentNode.replaceChild(clone, el);

                        // Add our own clean listener
                        clone.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopImmediatePropagation();
                            var drawer  = document.getElementById('arch-cart-drawer');
                            var overlay = document.getElementById('arch-cart-overlay');
                            if (drawer)  { drawer.classList.add('arch-open');  drawer.setAttribute('aria-hidden','false'); }
                            if (overlay) { overlay.classList.add('arch-open'); }
                            document.body.classList.add('arch-drawer-open');
                            return false;
                        }, true); // useCapture = true → fires before bubbled events
                    });
                });
            }

            // Run on DOM ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', patchHfeCart);
            } else {
                patchHfeCart();
            }

            // Also run after a short delay in case Elementor renders late
            setTimeout(patchHfeCart, 500);
            setTimeout(patchHfeCart, 1500);
        })();
    " );
	// AJAX add-to-cart on single product pages (opt-in via settings).
	if ( is_product() && arch_side_cart_get_option( 'enable_ajax_add_to_cart' ) ) {
		// Single-quoted PHP string: no PHP variable interpolation / escaping issues for the JS.
		wp_add_inline_script( 'arch-side-cart', '
			jQuery(function ($) {
				$("form.cart").on("submit.archAjax", function (e) {
					var $form = $(this);

					// Only simple + variable products. Grouped/external/etc. use the normal form submit.
					if ($form.hasClass("grouped_form") || $form.hasClass("variations_form") === false && $form.find("[name=add-to-cart]").length === 0) return;

					var $btn      = $form.find("button[name=add-to-cart], button.single_add_to_cart_button").first();
					var productId = $form.find("[name=add-to-cart]").val() || $form.find("[name=product_id]").val();
					if (!productId) return;
					if ($btn.hasClass("disabled") || $btn.is(":disabled")) return;

					e.preventDefault();
					if ($form.data("archBusy")) return;
					$form.data("archBusy", true);
					$btn.addClass("loading");

					var data = {
						action: "arch_add_to_cart",
						nonce: archCart.nonce,
						product_id: productId,
						quantity: $form.find("[name=quantity]").val() || 1,
						variation_id: $form.find("[name=variation_id]").val() || 0
					};
					$form.find("[name^=attribute_]").each(function () { data[this.name] = $(this).val(); });

					$.post(archCart.ajaxUrl, data).done(function (res) {
						if (res && res.success) {
							$(document.body).trigger("arch_added_to_cart", [res.data]);
						} else {
							archFallback();
						}
					}).fail(archFallback).always(function () {
						$form.data("archBusy", false);
						$btn.removeClass("loading");
					});

					// If AJAX fails (out of stock, missing options, network...) let WooCommerce
					// handle the click normally so the customer still sees the proper notice.
					function archFallback() {
						$form.off("submit.archAjax");
						if ($btn.length) { $btn[0].click(); } else { $form[0].submit(); }
					}
				});
			});
		' );
	}
}

/**
 * Inject the cart drawer HTML into wp_footer.
 */
add_action( 'wp_footer', 'arch_side_cart_render_drawer' );
function arch_side_cart_render_drawer() {
    if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
        return;
    }
    include ARCH_SIDE_CART_PATH . 'templates/mini-cart.php';
}

/**
 * WooCommerce fragments – refresh drawer HTML on cart update.
 */
add_filter( 'woocommerce_add_to_cart_fragments', 'arch_side_cart_fragments' );
function arch_side_cart_fragments( $fragments ) {
    $fragments['#arch-cart-drawer-inner'] = arch_render_cart_drawer_inner();
    return $fragments;
}
