<?php
// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Shared security gate for every AJAX handler.
 *
 * SECURITY: CSRF - verifies the nonce created in arch_side_cart_enqueue().
 * These actions are intentionally available to guests (wp_ajax_nopriv_*)
 * because they only touch the visitor's OWN session cart; no admin data or
 * other users' data is read or written, so no capability check applies.
 */
function arch_ajax_verify() {
    if ( ! check_ajax_referer( 'arch_side_cart_nonce', 'nonce', false ) ) {
        wp_send_json_error( [ 'message' => esc_html__( 'Security check failed.', 'arch-side-cart' ) ], 403 );
    }

    // Make sure the WooCommerce cart/session is available in this request.
    if ( function_exists( 'wc_load_cart' ) && null === WC()->cart ) {
        wc_load_cart();
    }
    if ( ! WC()->cart ) {
        wp_send_json_error( [ 'message' => esc_html__( 'Cart unavailable.', 'arch-side-cart' ) ], 500 );
    }
}

/**
 * SECURITY: read a cart item key from $_POST, unslashed + sanitized immediately.
 * Cart keys are lowercase md5 hashes, so sanitize_key() is lossless.
 */
function arch_ajax_get_posted_key() {
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in arch_ajax_verify().
    return isset( $_POST['cart_item_key'] ) ? sanitize_key( wp_unslash( $_POST['cart_item_key'] ) ) : '';
}

/**
 * Send the refreshed drawer back to the browser.
 */
function arch_ajax_send_cart() {
    WC()->cart->calculate_totals();
    wp_send_json_success(
        [
            'html'  => arch_render_cart_drawer_inner(), // Already passed through wp_kses_post().
            'count' => arch_cart_item_count(),
        ]
    );
}

/**
 * Return fresh cart HTML.
 */
function arch_ajax_get_cart() {
    arch_ajax_verify();
    arch_ajax_send_cart();
}
add_action( 'wp_ajax_arch_get_cart',        'arch_ajax_get_cart' );
add_action( 'wp_ajax_nopriv_arch_get_cart', 'arch_ajax_get_cart' );

/**
 * Update item quantity.
 * Expects: cart_item_key, quantity (int, 0 = remove).
 */
function arch_ajax_update_qty() {
    arch_ajax_verify();

    $key = arch_ajax_get_posted_key();
    // SECURITY: absint() guarantees a non-negative integer; cap to a sane ceiling.
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified above.
    $qty = isset( $_POST['quantity'] ) ? min( 9999, absint( wp_unslash( $_POST['quantity'] ) ) ) : 1;

    if ( '' === $key ) {
        wp_send_json_error( [ 'message' => esc_html__( 'Invalid item.', 'arch-side-cart' ) ], 400 );
    }

    $cart = WC()->cart->get_cart();
    if ( ! isset( $cart[ $key ] ) ) {
        wp_send_json_error( [ 'message' => esc_html__( 'Item not found.', 'arch-side-cart' ) ], 404 );
    }

    if ( 0 === $qty ) {
        WC()->cart->remove_cart_item( $key );
    } else {
        WC()->cart->set_quantity( $key, arch_clamp_qty_for_item( $cart[ $key ], $qty ) );
    }

    arch_ajax_send_cart();
}
add_action( 'wp_ajax_arch_update_qty',        'arch_ajax_update_qty' );
add_action( 'wp_ajax_nopriv_arch_update_qty', 'arch_ajax_update_qty' );

/**
 * Remove item from cart.
 * Expects: cart_item_key.
 */
function arch_ajax_remove_item() {
    arch_ajax_verify();

    $key  = arch_ajax_get_posted_key();
    $cart = WC()->cart->get_cart();

    // SECURITY: only act on keys that really exist in THIS visitor's cart.
    if ( '' !== $key && isset( $cart[ $key ] ) ) {
        WC()->cart->remove_cart_item( $key );
    }

    arch_ajax_send_cart();
}
add_action( 'wp_ajax_arch_remove_item',        'arch_ajax_remove_item' );
add_action( 'wp_ajax_nopriv_arch_remove_item', 'arch_ajax_remove_item' );

/**
 * Add N more of an item (upsell "Add N" button).
 * Expects: cart_item_key, add_qty (optional, defaults to 1).
 */
function arch_ajax_add_one() {
    arch_ajax_verify();

    $key = arch_ajax_get_posted_key();
    // SECURITY: integer-only, min 1, capped.
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified above.
    $add_qty = isset( $_POST['add_qty'] ) ? min( 999, max( 1, absint( wp_unslash( $_POST['add_qty'] ) ) ) ) : 1;
    $cart    = WC()->cart->get_cart();

    if ( '' !== $key && isset( $cart[ $key ] ) ) {
        $new_qty = (int) $cart[ $key ]['quantity'] + $add_qty;
        WC()->cart->set_quantity( $key, arch_clamp_qty_for_item( $cart[ $key ], $new_qty ) );
    }

    arch_ajax_send_cart();
}
add_action( 'wp_ajax_arch_add_one',        'arch_ajax_add_one' );
add_action( 'wp_ajax_nopriv_arch_add_one', 'arch_ajax_add_one' );

/**
 * AJAX add-to-cart for single product pages / [arch_buy_now].
 * Expects: product_id, quantity (default 1), variation_id + attribute_* (variable products).
 */
function arch_ajax_add_to_cart() {
    arch_ajax_verify();

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in arch_ajax_verify().
    $product_id   = isset( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
    $quantity     = isset( $_POST['quantity'] ) ? min( 9999, max( 1, absint( wp_unslash( $_POST['quantity'] ) ) ) ) : 1;
    $variation_id = isset( $_POST['variation_id'] ) ? absint( wp_unslash( $_POST['variation_id'] ) ) : 0;
    // phpcs:enable

    // SECURITY: validate the product exists, is published and purchasable.
    $product = $product_id ? wc_get_product( $product_id ) : false;
    if ( ! $product || 'publish' !== get_post_status( $product_id ) || ! $product->is_purchasable() ) {
        wp_send_json_error( [ 'message' => esc_html__( 'Invalid product.', 'arch-side-cart' ) ], 400 );
    }

    // SECURITY: a variation must belong to the submitted parent product.
    if ( $variation_id ) {
        $variation_obj = wc_get_product( $variation_id );
        if ( ! $variation_obj || (int) $variation_obj->get_parent_id() !== $product_id ) {
            wp_send_json_error( [ 'message' => esc_html__( 'Invalid variation.', 'arch-side-cart' ) ], 400 );
        }
    }

    $variation = [];
    if ( $variation_id ) {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified above.
        foreach ( array_keys( $_POST ) as $raw_name ) {
            // SECURITY: sanitize the field name first, then only accept attribute_* keys.
            $name = sanitize_title( wp_unslash( $raw_name ) );
            if ( 0 !== strpos( $name, 'attribute_' ) ) {
                continue;
            }
            // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce verified; value cleaned by wc_clean().
            $variation[ $name ] = wc_clean( wp_unslash( $_POST[ $raw_name ] ) );
        }
    }

    // Let WooCommerce and other plugins validate (stock, required fields, etc.).
    $passed = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity, $variation_id, $variation );
    $added  = $passed ? WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation ) : false;

    // The drawer replaces WooCommerce's "added to cart" notice.
    wc_clear_notices();

    if ( ! $added ) {
        wp_send_json_error( [ 'message' => esc_html__( 'Could not add product to cart.', 'arch-side-cart' ) ], 400 );
    }

    arch_ajax_send_cart();
}
add_action( 'wp_ajax_arch_add_to_cart',        'arch_ajax_add_to_cart' );
add_action( 'wp_ajax_nopriv_arch_add_to_cart', 'arch_ajax_add_to_cart' );
