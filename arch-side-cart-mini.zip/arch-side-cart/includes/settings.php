<?php
// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Default plugin settings.
 */
function arch_side_cart_defaults() {
    return [
        // Shipping & discounts.
        'show_shipping_bar'        => true,
        'free_shipping_threshold'  => 100,
        'enable_discounts'         => true,
        'quantity_discount_tiers'  => [
            [ 'min_qty' => 2,  'max_qty' => 3,  'pct' => 5 ],
            [ 'min_qty' => 4,  'max_qty' => 8,  'pct' => 10 ],
            [ 'min_qty' => 9,  'max_qty' => 10, 'pct' => 20 ],
            [ 'min_qty' => 11, 'max_qty' => '', 'pct' => 30 ], // empty max_qty = "and above"
        ],

        // Behaviour.
        'enable_ajax_add_to_cart'  => false,

        // Appearance.
        'accent_color'             => '#046bd2',
        'show_badge'               => true,

        // Text & labels.
        'cart_title'               => 'Your Cart',
        'checkout_button_text'     => 'Secure Checkout',
        'badge_text'               => 'COA verified',
        'shipping_progress_text'   => 'Add {amount} more for free shipping',
        'shipping_unlocked_text'   => 'FREE EXPRESS SHIPPING UNLOCKED',
        'tax_note'                 => 'Shipping & taxes calculated at checkout.',
        'empty_cart_text'          => 'Your cart is empty.',
        'discount_label'           => 'Quantity Discount',
    ];
}

function arch_side_cart_get_option( $key ) {
    $opts     = get_option( 'arch_side_cart_options', [] );
    $defaults = arch_side_cart_defaults();
    return isset( $opts[ $key ] ) ? $opts[ $key ] : ( $defaults[ $key ] ?? null );
}

/**
 * One-time upgrade routine for sites running an older version.
 *  - Old default accent (green) becomes the new default (blue).
 *  - "show_coa_badge" is renamed to "show_badge".
 */
add_action( 'admin_init', 'arch_side_cart_maybe_upgrade' );
function arch_side_cart_maybe_upgrade() {
    // SECURITY: admin_init also fires for low-privileged users / admin-ajax; only admins may write options.
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    if ( get_option( 'arch_side_cart_db_version' ) === ARCH_SIDE_CART_VERSION ) return;

    $opts = get_option( 'arch_side_cart_options', null );
    if ( is_array( $opts ) ) {
        if ( isset( $opts['accent_color'] ) && strtolower( $opts['accent_color'] ) === '#adff2f' ) {
            $opts['accent_color'] = '#046bd2';
        }
        if ( isset( $opts['show_coa_badge'] ) ) {
            $opts['show_badge'] = $opts['show_coa_badge'];
            unset( $opts['show_coa_badge'] );
        }
        update_option( 'arch_side_cart_options', $opts );
    }
    update_option( 'arch_side_cart_db_version', ARCH_SIDE_CART_VERSION );
}

add_action( 'admin_init', 'arch_side_cart_register_settings' );
function arch_side_cart_register_settings() {
    register_setting( 'arch_side_cart_group', 'arch_side_cart_options', [
        'type'              => 'array',
        'sanitize_callback' => 'arch_side_cart_sanitize',
        'default'           => arch_side_cart_defaults(),
        'show_in_rest'      => false,
    ] );
}

// SECURITY: options.php verifies the settings nonce (via settings_fields()) and this capability.
add_filter( 'option_page_capability_arch_side_cart_group', function () {
    return 'manage_options';
} );

function arch_side_cart_sanitize( $input ) {
    // SECURITY: defence in depth - never persist settings for users without the capability.
    if ( ! current_user_can( 'manage_options' ) ) {
        $existing = get_option( 'arch_side_cart_options', [] );
        return is_array( $existing ) ? $existing : [];
    }

    $d     = arch_side_cart_defaults();
    $input = is_array( $input ) ? $input : [];
    $clean = [];

    $clean['show_shipping_bar']       = ! empty( $input['show_shipping_bar'] );
    $clean['free_shipping_threshold'] = isset( $input['free_shipping_threshold'] ) ? max( 0, (float) wc_format_decimal( wp_unslash( $input['free_shipping_threshold'] ) ) ) : $d['free_shipping_threshold'];
    $clean['enable_discounts']        = ! empty( $input['enable_discounts'] );
    $clean['quantity_discount_tiers'] = arch_side_cart_sanitize_tiers( $input['quantity_discount_tiers'] ?? [] );
    $clean['enable_ajax_add_to_cart'] = ! empty( $input['enable_ajax_add_to_cart'] );

    $accent                           = sanitize_hex_color( isset( $input['accent_color'] ) ? sanitize_text_field( wp_unslash( $input['accent_color'] ) ) : '' );
    $clean['accent_color']            = $accent ? $accent : $d['accent_color'];
    $clean['show_badge']              = ! empty( $input['show_badge'] );

    foreach ( [ 'cart_title', 'checkout_button_text', 'badge_text', 'shipping_progress_text', 'shipping_unlocked_text', 'tax_note', 'empty_cart_text', 'discount_label' ] as $key ) {
        $value         = isset( $input[ $key ] ) ? sanitize_text_field( wp_unslash( $input[ $key ] ) ) : '';
        $clean[ $key ] = $value !== '' ? $value : $d[ $key ];
    }

    return $clean;
}

/**
 * Sanitize the repeatable quantity-discount-tier rows submitted from the
 * settings form. Each row: min_qty (required, >=1), max_qty (optional —
 * empty/0 means "and above", i.e. an open-ended top tier), pct (0-100).
 * Rows missing a min_qty are dropped. Result is re-indexed and sorted by
 * min_qty ascending so tier lookups can rely on order.
 */
function arch_side_cart_sanitize_tiers( $raw_tiers ) {
    $clean = [];

    if ( ! is_array( $raw_tiers ) ) {
        return $clean;
    }

    foreach ( $raw_tiers as $row ) {
        if ( ! is_array( $row ) ) continue;

        $min_qty = isset( $row['min_qty'] ) ? absint( $row['min_qty'] ) : 0;
        $pct     = isset( $row['pct'] ) ? absint( $row['pct'] ) : 0;

        if ( $min_qty < 1 ) continue;

        $max_qty = '';
        if ( isset( $row['max_qty'] ) && $row['max_qty'] !== '' ) {
            $max_qty = absint( $row['max_qty'] );
            if ( $max_qty < $min_qty ) {
                $max_qty = '';
            }
        }

        $clean[] = [
            'min_qty' => $min_qty,
            'max_qty' => $max_qty,
            'pct'     => max( 0, min( 100, $pct ) ),
        ];
    }

    usort( $clean, function ( $a, $b ) {
        return $a['min_qty'] <=> $b['min_qty'];
    } );

    return array_values( $clean );
}

/**
 * Helpers for the accent colour: RGB triplet + readable text colour.
 */
function arch_side_cart_hex_to_rgb( $hex ) {
    $hex = ltrim( (string) $hex, '#' );
    if ( strlen( $hex ) === 3 ) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    if ( strlen( $hex ) !== 6 ) return [ 4, 107, 210 ];
    return [ hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) ];
}

function arch_side_cart_contrast_color( $hex ) {
    list( $r, $g, $b ) = arch_side_cart_hex_to_rgb( $hex );
    $luminance = ( 0.299 * $r + 0.587 * $g + 0.114 * $b ) / 255;
    return $luminance > 0.6 ? '#1d1d1f' : '#ffffff';
}
