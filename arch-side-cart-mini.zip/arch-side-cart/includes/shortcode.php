<?php
// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * [arch_buy_now] shortcode.
 *
 * Renders a "Buy Now" style banner button for a single product. Clicking
 * it adds 1x of that product to the cart via the same arch_add_to_cart
 * AJAX endpoint used by the single-product page integration (see
 * includes/ajax.php / arch_ajax_add_to_cart and includes/hooks.php), then
 * opens the side cart drawer the same way the rest of the plugin does
 * (by triggering 'arch_added_to_cart' on document.body, which
 * cart-drawer.js listens for).
 *
 * Usage:
 *   [arch_buy_now product_id="123"]
 *   [arch_buy_now product_id="123" show_price="yes"]
 *
 * Attributes:
 *   product_id  (required) WooCommerce product ID. Shortcode renders
 *               nothing (plus an admin-only notice) if missing/invalid.
 *   show_price  "yes" or "no" (default "no"). When "yes", prints the
 *               product's price (using WooCommerce's own get_price_html()
 *               so sale prices/ranges/currency formatting all work
 *               automatically) before the button, matching the markup
 *               shape of the original "From AED 469.00** / Buy Now" banner.
 */
add_shortcode( 'arch_buy_now', 'arch_buy_now_shortcode' );
function arch_buy_now_shortcode( $atts ) {
    $atts = shortcode_atts( [
        'product_id' => '',
        'show_price' => 'no',
    ], $atts, 'arch_buy_now' );

    // SECURITY: shortcode attributes are author-controlled input - cast/sanitize before use.
    $product_id = absint( $atts['product_id'] );
    $show_price = 'yes' === strtolower( sanitize_text_field( $atts['show_price'] ) );

    if ( ! $product_id ) {
        return current_user_can( 'manage_options' )
            ? '<p class="arch-buy-now-error">' . esc_html__( '[arch_buy_now] missing required product_id attribute.', 'arch-side-cart' ) . '</p>'
            : '';
    }

    $product = wc_get_product( $product_id );
    if ( ! $product ) {
        return current_user_can( 'manage_options' )
            /* translators: %d: product ID */
            ? '<p class="arch-buy-now-error">' . esc_html( sprintf( __( '[arch_buy_now] no product found for product_id="%d".', 'arch-side-cart' ), $product_id ) ) . '</p>'
            : '';
    }

    // Make sure our JS/CSS + archCart localized data are on the page even
    // if this shortcode is used somewhere arch_side_cart_enqueue() wasn't
    // already triggered to load them (e.g. a non-product page, a widget,
    // or a page builder section).
    if ( ! wp_script_is( 'arch-side-cart', 'enqueued' ) ) {
        wp_enqueue_script( 'arch-side-cart' );
        wp_enqueue_style( 'arch-side-cart' );
    }

    ob_start();
    ?>
    <div class="bnnr-btn-wr arch-buy-now-wrap">
        <?php if ( $show_price ) : ?>
            <span class="arch-buy-now-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
        <?php endif; ?>
        <a href="#"
           class="bnnr-btn arch-buy-now-btn"
           data-product-id="<?php echo esc_attr( $product_id ); ?>"
           role="button"
        ><?php esc_html_e( 'Buy Now', 'arch-side-cart' ); ?></a>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Inline JS for the [arch_buy_now] button click handler. Registered as
 * its own inline script attached to the 'arch-side-cart' handle (same
 * pattern as the single-product-page AJAX add-to-cart script in
 * includes/hooks.php), so it loads after cart-drawer.js and shares its
 * archCart.ajaxUrl / archCart.nonce localized values.
 *
 * Uses event delegation on document so it works no matter how many
 * [arch_buy_now] buttons are on the page, and works even if a button is
 * added to the DOM later (e.g. inside an AJAX-loaded product block).
 *
 * Single-quoted PHP string throughout — no $ variables need escaping —
 * to avoid the backslash-stripping issue that caused a JS syntax error
 * previously when this kind of inline script was written with double
 * quotes and \$ escapes.
 */
add_action( 'wp_enqueue_scripts', 'arch_buy_now_inline_script', 1000 );
function arch_buy_now_inline_script() {
    if ( ! wp_script_is( 'arch-side-cart', 'enqueued' ) && ! wp_script_is( 'arch-side-cart', 'registered' ) ) {
        return;
    }

    wp_add_inline_script( 'arch-side-cart', '
        jQuery(function ($) {
            $(document).on("click", ".arch-buy-now-btn", function (e) {
                e.preventDefault();

                var $btn = $(this);
                if ($btn.hasClass("arch-buy-now-loading")) return;

                var productId = $btn.data("productId");
                if (!productId) return;

                $btn.addClass("arch-buy-now-loading");

                $.post(archCart.ajaxUrl, {
                    action: "arch_add_to_cart",
                    nonce: archCart.nonce,
                    product_id: productId,
                    quantity: 1
                }, function (res) {
                    if (res && res.success) {
                        $(document.body).trigger("arch_added_to_cart", [res.data]);
                    }
                }).always(function () {
                    $btn.removeClass("arch-buy-now-loading");
                });
            });
        });
    ' );
}
