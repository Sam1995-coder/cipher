<?php
// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Admin settings screen: WooCommerce → Side Cart.
 */
add_action( 'admin_menu', 'arch_side_cart_admin_menu' );
function arch_side_cart_admin_menu() {
    $GLOBALS['arch_side_cart_hook'] = add_submenu_page(
        'woocommerce',
        __( 'Arch Side Cart', 'arch-side-cart' ),
        __( 'Side Cart', 'arch-side-cart' ),
        'manage_options',
        'arch-side-cart',
        'arch_side_cart_settings_page'
    );
}

add_action( 'admin_enqueue_scripts', 'arch_side_cart_admin_assets' );
function arch_side_cart_admin_assets( $hook ) {
    if ( empty( $GLOBALS['arch_side_cart_hook'] ) || $hook !== $GLOBALS['arch_side_cart_hook'] ) return;

    wp_enqueue_style( 'arch-side-cart-admin', ARCH_SIDE_CART_URL . 'assets/admin/admin.css', [], ARCH_SIDE_CART_VERSION );
    wp_enqueue_script( 'arch-side-cart-admin', ARCH_SIDE_CART_URL . 'assets/admin/admin.js', [], ARCH_SIDE_CART_VERSION, true );
    wp_localize_script( 'arch-side-cart-admin', 'archAdmin', [
        'currency' => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ),
    ] );
}

/* ---------- small rendering helpers ---------- */

function arch_asc_toggle( $name, $checked, $id ) {
    printf(
        '<label class="asc-switch"><input type="checkbox" id="%1$s" name="arch_side_cart_options[%2$s]" value="1" %3$s><span class="asc-slider" aria-hidden="true"></span></label>',
        esc_attr( $id ),
        esc_attr( $name ),
        checked( ! empty( $checked ), true, false )
    );
}

function arch_asc_row_open( $label, $desc = '', $for = '' ) {
    echo '<div class="asc-row"><div class="asc-row-label">';
    echo '<label' . ( $for ? ' for="' . esc_attr( $for ) . '"' : '' ) . '>' . esc_html( $label ) . '</label>';
    if ( $desc ) echo '<p>' . wp_kses( $desc, [ 'code' => [], 'strong' => [] ] ) . '</p>';
    echo '</div><div class="asc-row-control">';
}

function arch_asc_row_close() {
    echo '</div></div>';
}

function arch_asc_text_row( $opts, $key, $label, $desc = '' ) {
    arch_asc_row_open( $label, $desc, 'asc-' . $key );
    printf(
        '<input type="text" class="asc-input asc-wide" id="asc-%1$s" data-preview="%1$s" name="arch_side_cart_options[%1$s]" value="%2$s">',
        esc_attr( $key ),
        esc_attr( $opts[ $key ] )
    );
    arch_asc_row_close();
}

function arch_side_cart_settings_page() {
    // SECURITY: capability check (settings_fields() below emits the nonce verified by options.php).
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'You do not have permission to access this page.', 'arch-side-cart' ), 403 );
    }

    $opts     = get_option( 'arch_side_cart_options', [] );
    $defaults = arch_side_cart_defaults();
    $opts     = wp_parse_args( is_array( $opts ) ? $opts : [], $defaults );
    $currency = html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' );
    // SECURITY: read-only display flag; sanitized and compared to a fixed value (no state change).
    $saved    = isset( $_GET['settings-updated'] ) && 'true' === sanitize_text_field( wp_unslash( $_GET['settings-updated'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $swatches = [ '#046bd2', '#2563eb', '#7c3aed', '#db2777', '#ea580c', '#16a34a', '#0f172a' ];
    ?>
    <div class="wrap asc-wrap">
        <h1 class="screen-reader-text"><?php esc_html_e( 'Arch Side Cart Settings', 'arch-side-cart' ); ?></h1>
        <hr class="wp-header-end">

        <div class="asc-hero">
            <div class="asc-hero-brand">
                <span class="asc-logo" aria-hidden="true">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>
                </span>
                <div>
                    <h2><?php esc_html_e( 'Arch Side Cart', 'arch-side-cart' ); ?> <span class="asc-version">v<?php echo esc_html( ARCH_SIDE_CART_VERSION ); ?></span></h2>
                    <p><?php esc_html_e( 'A fast, conversion-focused slide-out cart for WooCommerce.', 'arch-side-cart' ); ?></p>
                </div>
            </div>
        </div>

        <?php if ( $saved ) : ?>
            <div class="asc-toast" role="status">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
                <?php esc_html_e( 'Settings saved.', 'arch-side-cart' ); ?>
            </div>
        <?php endif; ?>

        <form method="post" action="options.php" class="asc-form" id="asc-form">
            <?php settings_fields( 'arch_side_cart_group' ); ?>

            <div class="asc-layout">
                <div class="asc-main">
                    <nav class="asc-tabs" role="tablist">
                        <button type="button" class="asc-tab is-active" data-tab="general"    role="tab"><?php esc_html_e( 'General', 'arch-side-cart' ); ?></button>
                        <button type="button" class="asc-tab"           data-tab="discounts"  role="tab"><?php esc_html_e( 'Discounts', 'arch-side-cart' ); ?></button>
                        <button type="button" class="asc-tab"           data-tab="appearance" role="tab"><?php esc_html_e( 'Appearance', 'arch-side-cart' ); ?></button>
                        <button type="button" class="asc-tab"           data-tab="labels"     role="tab"><?php esc_html_e( 'Text &amp; Labels', 'arch-side-cart' ); ?></button>
                    </nav>

                    <!-- GENERAL -->
                    <section class="asc-panel is-active" data-panel="general">
                        <div class="asc-card">
                            <h3><?php esc_html_e( 'Free shipping', 'arch-side-cart' ); ?></h3>
                            <?php
                            arch_asc_row_open( __( 'Show free shipping bar', 'arch-side-cart' ), __( 'Display a progress bar at the top of the cart.', 'arch-side-cart' ), 'asc-show_shipping_bar' );
                            arch_asc_toggle( 'show_shipping_bar', $opts['show_shipping_bar'], 'asc-show_shipping_bar' );
                            arch_asc_row_close();

                            arch_asc_row_open( __( 'Free shipping threshold', 'arch-side-cart' ), __( 'Cart subtotal needed to unlock free shipping.', 'arch-side-cart' ), 'asc-free_shipping_threshold' );
                            ?>
                            <div class="asc-affix">
                                <span class="asc-affix-pre"><?php echo esc_html( $currency ); ?></span>
                                <input type="number" min="0" step="any" class="asc-input" id="asc-free_shipping_threshold" data-preview="free_shipping_threshold" name="arch_side_cart_options[free_shipping_threshold]" value="<?php echo esc_attr( $opts['free_shipping_threshold'] ); ?>">
                            </div>
                            <?php arch_asc_row_close(); ?>
                        </div>

                        <div class="asc-card">
                            <h3><?php esc_html_e( 'Behaviour', 'arch-side-cart' ); ?></h3>
                            <?php
                            arch_asc_row_open( __( 'Open cart after Add to Cart', 'arch-side-cart' ), __( 'On single product pages, add the product via AJAX and slide the cart open instead of reloading the page.', 'arch-side-cart' ), 'asc-enable_ajax_add_to_cart' );
                            arch_asc_toggle( 'enable_ajax_add_to_cart', $opts['enable_ajax_add_to_cart'], 'asc-enable_ajax_add_to_cart' );
                            arch_asc_row_close();
                            ?>
                        </div>

                        <div class="asc-card asc-card-muted">
                            <h3><?php esc_html_e( 'Shortcode', 'arch-side-cart' ); ?></h3>
                            <p class="asc-help"><?php esc_html_e( 'Add a Buy Now button anywhere that adds a product and opens the cart:', 'arch-side-cart' ); ?></p>
                            <code class="asc-code">[arch_buy_now product_id="123" show_price="yes"]</code>
                        </div>
                    </section>

                    <!-- DISCOUNTS -->
                    <section class="asc-panel" data-panel="discounts">
                        <div class="asc-card">
                            <h3><?php esc_html_e( 'Quantity discounts', 'arch-side-cart' ); ?></h3>
                            <?php
                            arch_asc_row_open( __( 'Enable quantity discounts', 'arch-side-cart' ), __( 'Reward customers for buying more of the same product. Also powers the &ldquo;Add N more, save X%&rdquo; prompt in the cart.', 'arch-side-cart' ), 'asc-enable_discounts' );
                            arch_asc_toggle( 'enable_discounts', $opts['enable_discounts'], 'asc-enable_discounts' );
                            arch_asc_row_close();
                            ?>
                            <div class="asc-tiers" id="asc-tiers">
                                <div class="asc-tier asc-tier-head">
                                    <span><?php esc_html_e( 'Qty from', 'arch-side-cart' ); ?></span>
                                    <span><?php esc_html_e( 'Qty to', 'arch-side-cart' ); ?></span>
                                    <span><?php esc_html_e( 'Discount', 'arch-side-cart' ); ?></span>
                                    <span></span>
                                </div>
                                <div id="asc-tier-rows" data-next="<?php echo esc_attr( count( $opts['quantity_discount_tiers'] ) ); ?>">
                                    <?php foreach ( $opts['quantity_discount_tiers'] as $i => $tier ) : ?>
                                        <div class="asc-tier asc-tier-row">
                                            <input type="number" min="1" step="1" class="asc-input" name="arch_side_cart_options[quantity_discount_tiers][<?php echo esc_attr( (int) $i ); ?>][min_qty]" value="<?php echo esc_attr( $tier['min_qty'] ); ?>" aria-label="<?php esc_attr_e( 'Quantity from', 'arch-side-cart' ); ?>">
                                            <input type="number" min="1" step="1" class="asc-input" name="arch_side_cart_options[quantity_discount_tiers][<?php echo esc_attr( (int) $i ); ?>][max_qty]" value="<?php echo esc_attr( $tier['max_qty'] ); ?>" placeholder="<?php esc_attr_e( 'and up', 'arch-side-cart' ); ?>" aria-label="<?php esc_attr_e( 'Quantity to', 'arch-side-cart' ); ?>">
                                            <div class="asc-affix asc-affix-post"><input type="number" min="0" max="100" step="1" class="asc-input" name="arch_side_cart_options[quantity_discount_tiers][<?php echo esc_attr( (int) $i ); ?>][pct]" value="<?php echo esc_attr( $tier['pct'] ); ?>" aria-label="<?php esc_attr_e( 'Discount percent', 'arch-side-cart' ); ?>"><span class="asc-affix-post-txt">%</span></div>
                                            <button type="button" class="asc-icon-btn asc-tier-remove" aria-label="<?php esc_attr_e( 'Remove tier', 'arch-side-cart' ); ?>">&times;</button>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <button type="button" class="asc-btn asc-btn-ghost" id="asc-tier-add">+ <?php esc_html_e( 'Add tier', 'arch-side-cart' ); ?></button>
                            <p class="asc-help"><?php esc_html_e( 'Leave &ldquo;Qty to&rdquo; blank on the last row for &ldquo;and above&rdquo;. Example: 2–3 → 5%, 4–8 → 10%, 11+ → 30%. Discounts apply per product line.', 'arch-side-cart' ); ?></p>
                        </div>
                    </section>

                    <!-- APPEARANCE -->
                    <section class="asc-panel" data-panel="appearance">
                        <div class="asc-card">
                            <h3><?php esc_html_e( 'Brand colour', 'arch-side-cart' ); ?></h3>
                            <?php arch_asc_row_open( __( 'Accent colour', 'arch-side-cart' ), __( 'Used for buttons, the progress bar, badges and highlights.', 'arch-side-cart' ), 'asc-accent_color_hex' ); ?>
                            <div class="asc-color">
                                <input type="color" id="asc-accent_color" value="<?php echo esc_attr( $opts['accent_color'] ); ?>" aria-label="<?php esc_attr_e( 'Pick colour', 'arch-side-cart' ); ?>">
                                <input type="text" class="asc-input asc-hex" id="asc-accent_color_hex" data-preview="accent_color" name="arch_side_cart_options[accent_color]" value="<?php echo esc_attr( $opts['accent_color'] ); ?>" maxlength="7" spellcheck="false">
                            </div>
                            <div class="asc-swatches">
                                <?php foreach ( $swatches as $s ) : ?>
                                    <button type="button" class="asc-swatch" data-color="<?php echo esc_attr( $s ); ?>" style="background:<?php echo esc_attr( $s ); ?>" aria-label="<?php echo esc_attr( $s ); ?>"></button>
                                <?php endforeach; ?>
                            </div>
                            <?php arch_asc_row_close(); ?>
                        </div>

                        <div class="asc-card">
                            <h3><?php esc_html_e( 'Product badge', 'arch-side-cart' ); ?></h3>
                            <?php
                            arch_asc_row_open( __( 'Show product badge', 'arch-side-cart' ), __( 'A small trust badge under each cart item, e.g. &ldquo;COA verified&rdquo;, &ldquo;Lab tested&rdquo; or &ldquo;100% authentic&rdquo;.', 'arch-side-cart' ), 'asc-show_badge' );
                            arch_asc_toggle( 'show_badge', $opts['show_badge'], 'asc-show_badge' );
                            arch_asc_row_close();

                            arch_asc_text_row( $opts, 'badge_text', __( 'Badge text', 'arch-side-cart' ), __( 'The text shown inside the badge.', 'arch-side-cart' ) );
                            ?>
                        </div>
                    </section>

                    <!-- LABELS -->
                    <section class="asc-panel" data-panel="labels">
                        <div class="asc-card">
                            <h3><?php esc_html_e( 'Cart', 'arch-side-cart' ); ?></h3>
                            <?php
                            arch_asc_text_row( $opts, 'cart_title', __( 'Cart title', 'arch-side-cart' ) );
                            arch_asc_text_row( $opts, 'checkout_button_text', __( 'Checkout button text', 'arch-side-cart' ) );
                            arch_asc_text_row( $opts, 'tax_note', __( 'Note under subtotal', 'arch-side-cart' ) );
                            arch_asc_text_row( $opts, 'empty_cart_text', __( 'Empty cart message', 'arch-side-cart' ) );
                            ?>
                        </div>
                        <div class="asc-card">
                            <h3><?php esc_html_e( 'Free shipping messages', 'arch-side-cart' ); ?></h3>
                            <?php
                            arch_asc_text_row( $opts, 'shipping_progress_text', __( 'Progress message', 'arch-side-cart' ), __( 'Shown while the customer is below the threshold. Use <code>{amount}</code> for the remaining amount.', 'arch-side-cart' ) );
                            arch_asc_text_row( $opts, 'shipping_unlocked_text', __( 'Unlocked message', 'arch-side-cart' ), __( 'Shown once the threshold is reached.', 'arch-side-cart' ) );
                            ?>
                        </div>
                        <div class="asc-card">
                            <h3><?php esc_html_e( 'Discounts', 'arch-side-cart' ); ?></h3>
                            <?php arch_asc_text_row( $opts, 'discount_label', __( 'Discount line label', 'arch-side-cart' ), __( 'The name of the discount line shown at checkout and in order emails.', 'arch-side-cart' ) ); ?>
                        </div>
                    </section>

                    <div class="asc-savebar">
                        <span class="asc-dirty" id="asc-dirty" hidden><?php esc_html_e( 'You have unsaved changes', 'arch-side-cart' ); ?></span>
                        <button type="submit" class="asc-btn asc-btn-primary"><?php esc_html_e( 'Save changes', 'arch-side-cart' ); ?></button>
                    </div>
                </div>

                <!-- LIVE PREVIEW -->
                <aside class="asc-aside" aria-label="<?php esc_attr_e( 'Live preview', 'arch-side-cart' ); ?>">
                    <div class="asc-preview-head">
                        <strong><?php esc_html_e( 'Live preview', 'arch-side-cart' ); ?></strong>
                        <div class="asc-seg" role="group">
                            <button type="button" class="is-active" data-state="locked"><?php esc_html_e( 'Progress', 'arch-side-cart' ); ?></button>
                            <button type="button" data-state="unlocked"><?php esc_html_e( 'Unlocked', 'arch-side-cart' ); ?></button>
                        </div>
                    </div>
                    <div class="asc-pv" id="asc-pv" data-state="locked">
                        <div class="asc-pv-header">
                            <div><small><?php esc_html_e( '2 ITEMS', 'arch-side-cart' ); ?></small><b data-bind="cart_title"></b></div>
                            <span class="asc-pv-x">&times;</span>
                        </div>
                        <div class="asc-pv-ship" data-bind-show="ship">
                            <div class="asc-pv-ship-label asc-pv-locked"></div>
                            <div class="asc-pv-ship-label asc-pv-unlocked"><span class="asc-pv-check">&#10003;</span><span data-bind="shipping_unlocked_text"></span></div>
                            <div class="asc-pv-track"><i></i></div>
                        </div>
                        <div class="asc-pv-item">
                            <div class="asc-pv-img"></div>
                            <div class="asc-pv-info">
                                <b><?php esc_html_e( 'SAMPLE PRODUCT', 'arch-side-cart' ); ?></b>
                                <span class="asc-pv-meta"><?php esc_html_e( 'Bundle discount: 5% off x 2', 'arch-side-cart' ); ?><em data-bind-show="badge"> &bull; <u data-bind="badge_text"></u></em></span>
                                <div class="asc-pv-qty"><span>&minus;</span><span>2</span><span>+</span></div>
                            </div>
                            <div class="asc-pv-price"><s><?php echo esc_html( $currency ); ?>60.00</s><b><?php echo esc_html( $currency ); ?>57.00</b><span class="asc-pv-save"><?php esc_html_e( 'SAVE', 'arch-side-cart' ); ?> <?php echo esc_html( $currency ); ?>3.00</span></div>
                        </div>
                        <div class="asc-pv-footer">
                            <div class="asc-pv-sub"><b><?php esc_html_e( 'Subtotal', 'arch-side-cart' ); ?></b><b><?php echo esc_html( $currency ); ?>57.00</b></div>
                            <small data-bind="tax_note"></small>
                            <div class="asc-pv-btn"><span data-bind="checkout_button_text"></span> &rarr;</div>
                            <div class="asc-pv-link"><?php esc_html_e( 'VIEW CART', 'arch-side-cart' ); ?></div>
                        </div>
                    </div>
                </aside>
            </div>

            <template id="asc-tier-template">
                <div class="asc-tier asc-tier-row">
                    <input type="number" min="1" step="1" class="asc-input" name="arch_side_cart_options[quantity_discount_tiers][__I__][min_qty]" aria-label="<?php esc_attr_e( 'Quantity from', 'arch-side-cart' ); ?>">
                    <input type="number" min="1" step="1" class="asc-input" name="arch_side_cart_options[quantity_discount_tiers][__I__][max_qty]" placeholder="<?php esc_attr_e( 'and up', 'arch-side-cart' ); ?>" aria-label="<?php esc_attr_e( 'Quantity to', 'arch-side-cart' ); ?>">
                    <div class="asc-affix asc-affix-post"><input type="number" min="0" max="100" step="1" class="asc-input" name="arch_side_cart_options[quantity_discount_tiers][__I__][pct]" aria-label="<?php esc_attr_e( 'Discount percent', 'arch-side-cart' ); ?>"><span class="asc-affix-post-txt">%</span></div>
                    <button type="button" class="asc-icon-btn asc-tier-remove" aria-label="<?php esc_attr_e( 'Remove tier', 'arch-side-cart' ); ?>">&times;</button>
                </div>
            </template>
        </form>
    </div>
    <?php
}
