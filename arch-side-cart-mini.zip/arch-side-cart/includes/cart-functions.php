<?php
// Security: block direct file access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Render the #arch-cart-drawer-inner wrapper with the current cart contents
 * and return it as a string.
 *
 * Used by every AJAX handler / fragments filter that refreshes the drawer,
 * so the returned HTML always includes the #arch-cart-drawer-inner id that
 * cart-drawer.js re-selects after each replaceWith() call. Do not use the
 * full templates/mini-cart.php here — that file also prints the overlay and
 * outer #arch-cart-drawer wrapper, which would nest a duplicate drawer.
 */
function arch_render_cart_drawer_inner() {
    ob_start();
    ?>
    <div id="arch-cart-drawer-inner" class="arch-cart-inner">
        <?php include ARCH_SIDE_CART_PATH . 'templates/mini-cart-inner.php'; ?>
    </div>
    <?php
    // SECURITY: escape late - everything leaving this function (page load, AJAX, fragments) is kses-filtered.
    return wp_kses_post( ob_get_clean() );
}

/**
 * Total number of items in cart.
 */
function arch_cart_item_count() {
    return WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0;
}

/**
 * Cart subtotal (float).
 */
function arch_cart_subtotal() {
    return WC()->cart ? (float) WC()->cart->get_subtotal() : 0.0;
}

/**
 * Amount shown as "Subtotal" in the drawer: item subtotal plus fees (the
 * quantity discount is a negative fee). Shipping is deliberately excluded
 * because the drawer says it is calculated at checkout.
 */
function arch_cart_total() {
    $cart = WC()->cart;
    if ( ! $cart ) return 0;

    $total = (float) $cart->get_subtotal() + (float) $cart->get_fee_total();

    // Prices displayed including tax: add the tax on items and fees too.
    if ( $cart->display_prices_including_tax() ) {
        $total += (float) $cart->get_subtotal_tax() + (float) $cart->get_fee_tax();
    }
    return max( 0, $total );
}

/**
 * How much more the customer needs for free shipping.
 */
function arch_free_shipping_remaining() {
    $threshold = (float) arch_side_cart_get_option( 'free_shipping_threshold' );
    $subtotal  = arch_cart_subtotal();
    return max( 0, $threshold - $subtotal );
}

/**
 * Percentage progress toward free shipping (0-100).
 */
function arch_free_shipping_progress() {
    $threshold = (float) arch_side_cart_get_option( 'free_shipping_threshold' );
    if ( $threshold <= 0 ) return 100;
    return min( 100, round( ( arch_cart_subtotal() / $threshold ) * 100 ) );
}

/**
 * Get the configured quantity-discount tiers, sorted by min_qty ascending.
 * Each tier: [ 'min_qty' => int, 'max_qty' => int|'', 'pct' => int ].
 * An empty 'max_qty' means that tier is open-ended ("and above").
 */
function arch_get_quantity_discount_tiers() {
    if ( ! arch_side_cart_get_option( 'enable_discounts' ) ) {
        return [];
    }
    $tiers = arch_side_cart_get_option( 'quantity_discount_tiers' );
    return is_array( $tiers ) ? $tiers : [];
}

/**
 * Find the tier a given quantity currently qualifies for (the highest
 * tier whose range the qty falls into). Returns null if qty doesn't
 * reach even the first tier.
 */
function arch_get_tier_for_qty( $qty ) {
    $matched = null;
    foreach ( arch_get_quantity_discount_tiers() as $tier ) {
        $in_range = $qty >= $tier['min_qty'] && ( $tier['max_qty'] === '' || $qty <= $tier['max_qty'] );
        if ( $in_range ) {
            $matched = $tier; // tiers are sorted ascending, so the last match wins if ranges ever overlap
        }
    }
    return $matched;
}

/**
 * Find the next higher tier above the given quantity (used for the
 * "Add N more, save X%" upsell message). Returns null if the qty has
 * already reached the highest configured tier, or no tiers are set.
 */
function arch_get_next_tier_for_qty( $qty ) {
    $next = null;
    foreach ( arch_get_quantity_discount_tiers() as $tier ) {
        if ( $tier['min_qty'] > $qty ) {
            if ( $next === null || $tier['min_qty'] < $next['min_qty'] ) {
                $next = $tier;
            }
        }
    }
    return $next;
}

/**
 * Build the bundle-discount message for a cart item, e.g. "Bundle discount: 10% off x 5".
 * Returns empty string if the item's quantity doesn't qualify for any tier.
 */
function arch_item_bundle_message( $cart_item ) {
    $qty  = (int) $cart_item['quantity'];
    $tier = arch_get_tier_for_qty( $qty );

    if ( $tier && $tier['pct'] > 0 ) {
        /* translators: 1: discount percent, 2: quantity */
        return sprintf( __( 'Bundle discount: %1$d%% off x %2$d', 'arch-side-cart' ), (int) $tier['pct'], $qty );
    }
    return '';
}

/**
 * Build the "Add N more, save X%" upsell message for a cart item, based
 * on the next quantity-discount tier above its current quantity.
 */
function arch_item_upsell_message( $cart_item ) {
    $qty  = (int) $cart_item['quantity'];
    $next = arch_get_next_tier_for_qty( $qty );

    if ( $next ) {
        $need = $next['min_qty'] - $qty;
        /* translators: 1: quantity to add, 2: discount percent */
        return sprintf( __( 'Add %1$d more, save %2$d%%', 'arch-side-cart' ), (int) $need, (int) $next['pct'] );
    }
    return '';
}

/**
 * How many more of this item to add to reach the next discount tier.
 * Used to set the upsell "Add N" button to add the correct quantity
 * (not always 1) so one click jumps straight to the next tier.
 */
function arch_item_upsell_qty_needed( $cart_item ) {
    $qty  = (int) $cart_item['quantity'];
    $next = arch_get_next_tier_for_qty( $qty );
    return $next ? max( 1, $next['min_qty'] - $qty ) : 0;
}

/**
 * Apply the quantity-discount tiers automatically.
 * Called on woocommerce_cart_calculate_fees. Each cart line's quantity
 * is checked against the configured tiers independently, so different
 * products in the same cart can land in different tiers.
 */
function arch_apply_bundle_discount( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;

    // NOTE: no "run once per request" guard here. WooCommerce already
    // resets the cart's fees array at the start of every calculate_fees()
    // pass, so add_fee() below never double-stacks even if calculate_totals()
    // runs more than once in the same request (e.g. set_quantity() triggers
    // its own internal calculate_totals(), and our AJAX handlers call it
    // again explicitly). A did_action()-based guard caused the 2nd pass to
    // skip re-adding the fee while still recalculating the total, so the
    // total briefly equaled the undiscounted subtotal after qty changes.

    $total_discount = 0.0;

    foreach ( $cart->get_cart() as $item ) {
        $tier = arch_get_tier_for_qty( (int) $item['quantity'] );
        if ( $tier && $tier['pct'] > 0 ) {
            $line_total      = (float) $item['line_total'];
            $total_discount += $line_total * ( $tier['pct'] / 100 );
        }
    }

    if ( $total_discount > 0 ) {
        $cart->add_fee( arch_side_cart_get_option( 'discount_label' ), -$total_discount, true );
    }
}
add_action( 'woocommerce_cart_calculate_fees', 'arch_apply_bundle_discount' );


/**
 * Clamp a requested quantity to what the product can actually be sold in
 * (stock levels / sold-individually). Returns the allowed quantity.
 */
function arch_clamp_qty_for_item( $cart_item, $qty ) {
    $product = isset( $cart_item['data'] ) ? $cart_item['data'] : null;
    if ( ! $product ) return $qty;

    $max = $product->get_max_purchase_quantity(); // -1 = unlimited
    if ( $max > 0 && $qty > $max ) {
        return (int) $max;
    }
    return $qty;
}
